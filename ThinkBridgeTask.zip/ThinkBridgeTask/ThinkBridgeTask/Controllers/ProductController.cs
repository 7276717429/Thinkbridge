﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ThinkBridgeTask.Models;

namespace ThinkBridgeTask.Controllers
{
    
    public class ProductController : ApiController
    {
        PracticeEntities db;

        public ProductController()
        {
            db = new PracticeEntities();
        }

       
        [HttpGet]
        [Route("api/product")]
        public List<tblProduct> GetAllProdutc()
        {
            List<tblProduct> lst = db.tblProducts.ToList();
            return lst;
        }

        [HttpGet]
        [Route("api/Product/{id}")]
        public tblProduct GetProductByID(int id)
        {
            tblProduct tbl = db.tblProducts.Find(id);
            return tbl;
        }
        [HttpPost]
        [Route("api/Product")]
        public string AddProduct(tblProduct p)
        {
            db.tblProducts.Add(p);
            db.SaveChanges();
            return "Product added  successfully";
        }

        [HttpPut]
        [Route("api/Product")]
        public string UpdateProduct(tblProduct p)
        {

            db.Entry<tblProduct>(p).State = EntityState.Modified;
            db.SaveChanges();
            return "Product  update successfully";
        }
        [HttpDelete]
        [Route("api/Product/{id}")]
        public string DeleteProduct(int id)
        {
            tblProduct tbl = db.tblProducts.Find(id);
            db.tblProducts.Remove(tbl);
            db.SaveChanges();
            return "Product deleted  successfully";
        }



    }
}
